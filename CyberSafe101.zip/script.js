function showTip() {
  const tips = [
    "Never share your password with anyone.",
    "Use a VPN when on public Wi-Fi.",
    "Keep your browser and OS updated.",
    "Avoid clicking unknown email links.",
    "Use unique passwords for each account."
  ];
  const randomIndex = Math.floor(Math.random() * tips.length);
  document.getElementById("tipDisplay").innerText = tips[randomIndex];
}
